//
//  main.cpp
//  OnePizzaType
//
//  Created by Cindy Solomon on 2/13/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#include <iostream>
#include "OnePizzaType.hpp"

int main(int argc, const char * argv[]) {
    // insert code here...

    Pizza basicPizza;

    basicPizza = orderPizza();

    return 0;

}
