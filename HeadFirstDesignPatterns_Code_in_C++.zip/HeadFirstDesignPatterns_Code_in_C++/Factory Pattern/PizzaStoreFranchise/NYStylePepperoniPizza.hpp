//
//  NYStylePepperoniPizza.hpp
//  PizzaStoreFranchise
//
//  Created by Cindy Solomon on 2/21/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#ifndef NYStylePepperoniPizza_hpp
#define NYStylePepperoniPizza_hpp

#include "Pizza.hpp"

class NYStylePepperoniPizza: public Pizza
{
public:

    NYStylePepperoniPizza();

};

#endif /* NYStylePepperoniPizza_hpp */
