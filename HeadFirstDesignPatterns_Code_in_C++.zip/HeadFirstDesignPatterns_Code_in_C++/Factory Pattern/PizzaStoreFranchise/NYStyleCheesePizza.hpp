//
//  NYStyleCheesePizza.hpp
//  PizzaStoreFranchise
//
//  Created by Cindy Solomon on 2/21/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#ifndef NYStyleCheesePizza_hpp
#define NYStyleCheesePizza_hpp

#include "Pizza.hpp"

class NYStyleCheesePizza: public Pizza
{
    public:

    NYStyleCheesePizza();

};

#endif /* NYStyleCheesePizza_hpp */
