//
//  ChicagoStyleVeggiePizza.hpp
//  PizzaStoreFranchise
//
//  Created by Cindy Solomon on 2/20/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#ifndef ChicagoStyleVeggiePizza_hpp
#define ChicagoStyleVeggiePizza_hpp

#include "Pizza.hpp"

class ChicagoStyleVeggiePizza: public Pizza
{
    public:

    ChicagoStyleVeggiePizza();

};

#endif /* ChicagoStyleVeggiePizza_hpp */
