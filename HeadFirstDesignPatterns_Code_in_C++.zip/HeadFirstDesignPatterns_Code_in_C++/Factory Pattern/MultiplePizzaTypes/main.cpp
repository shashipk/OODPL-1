//
//  main.cpp
//  MultiplePizzaType
//
//  Created by Cindy Solomon on 2/13/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#include "MultiplePizzaTypes.hpp"

int main(int argc, const char * argv[]) {
    // insert code here...

    orderPizza("cheese");

    orderPizza("pepperoni");

    return 0;

}
