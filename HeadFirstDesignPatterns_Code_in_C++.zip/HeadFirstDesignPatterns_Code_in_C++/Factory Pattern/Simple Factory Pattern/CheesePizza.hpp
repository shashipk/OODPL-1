//
//  CheesePizza.hpp
//  Factory Pattern
//
//  Created by Cindy Solomon on 2/13/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#ifndef CheesePizza_hpp
#define CheesePizza_hpp

#include "Pizza.hpp"

class CheesePizza: public Pizza
{
    public:

    CheesePizza();
//    void prepare() override;
//    void bake() override;
//    void cut() override;
//    void box() override;

};

#endif /* CheesePizza_hpp */
