//
//  VeggiePizza.hpp
//  SimpleFactoryPattern
//
//  Created by Cindy Solomon on 2/20/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#ifndef VeggiePizza_hpp
#define VeggiePizza_hpp

#include "Pizza.hpp"

class VeggiePizza: public Pizza
{
    public:

    VeggiePizza();
//    void prepare() override;
//    void bake() override;
//    void cut() override;
//    void box() override;

};

#endif /* VeggiePizza_hpp */
