//
//  WeatherStation.hpp
//  Observer Pattern
//
//  Created by Abhinay Reddyreddy on 2/21/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#ifndef WeatherStation2_hpp
#define WeatherStation2_hpp

void WeatherStationWithFunctions();

#endif /* WeatherStation_hpp */
