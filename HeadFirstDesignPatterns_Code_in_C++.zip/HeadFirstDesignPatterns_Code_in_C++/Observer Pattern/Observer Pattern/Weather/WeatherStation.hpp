//
//  WeatherStation.hpp
//  Observer Pattern
//
//  Created by Abhinay Reddyreddy on 2/21/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#ifndef WeatherStation_hpp
#define WeatherStation_hpp

void WeatherStation();
void WeatherStationHeatIndex();

#endif /* WeatherStation_hpp */
