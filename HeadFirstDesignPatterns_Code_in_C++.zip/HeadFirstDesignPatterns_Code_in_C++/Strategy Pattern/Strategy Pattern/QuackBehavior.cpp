//
//  QuackBehavior.cpp
//  Strategy Pattern
//
//  Created by Brian Arnold on 1/4/18.
//  Copyright © 2018 Brian Arnold. All rights reserved.
//

#include "QuackBehavior.hpp"
